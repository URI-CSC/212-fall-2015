#pragma once
#include <vector>

void quicksort(std::vector<int> &v);
