#pragma once
#include <vector>

void quicksort_median_pivot(std::vector<int> &v);
